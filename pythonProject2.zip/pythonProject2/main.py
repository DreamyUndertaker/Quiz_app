import tkinter as tk
from tkinter import messagebox
from datetime import datetime
from MultipleChoice import MultipleChoice
from OneChoice import OneChoice
from CheckDataEdit import CheckDataEdit
from PartOfSpeech import PartOfSpeechQuestion
from DragText import DragAndDrop


class QuestionManager:
    def __init__(self, root):
        self.root = root
        self.current_question_index = 0
        self.dict = {}
        self.questions = [
            {
                "type": "CheckDataEdit",
                "data": (
                    "Вопрос 1: В каком году родился Пушкин. А. С.?",
                    ["1799"])
            },
            {
                "type": "MultipleChoice",
                "data": ("Вопрос 2: В каких годах Достоевский написал «Преступление и наказание»?",
                         ["(1786-1787)", "(1865-1866)", "(1856-1857)"], [0, 1, 0])
            },
            {
                "type": "OneChoice",
                "data": ("Вопрос 3: Из какого произведения эта цитата: «И дым отечества нам сладок и приятен»?",
                         ["(«Горе от ума» Грибоедов А.С.)", "(«Евгений Онегин» Пушкин А.С.)", "(«Мцыри» ЛермонтовМ.Ю.)"], 2)
            },
            {
                "type": "CheckDataEdit",
                "data": (
                    "Вопрос 4: Кто написал роман бесы?",
                    ["Достоевский"])
            },
            {
                "type": "OneChoice",
                "data": (
                    "Вопрос 5:Как звали девушку, в которую был влюблен главный герой романа А.С. Пушкина «Дубровский»?",

                    ["Софья Мармеладова", "Маша Троекурова", "Маша Гринева"], 1)
            },
            {
                "type": "OneChoice",
                "data": ("Вопрос 6 : Кто из героев пьесы Фонвизина 'Недоросль' произносит эти слова?\n Час моей воли пришёл. Не хочу учиться, хочу жениться. Ты ж меня взманила, пеняй на себя.",
                         ["Митрофанушка", "Кутейкин", "Скоткин"], 0)
            },
            {
                "type": "PartOfSpeech",
                "data": ("Вопрос 7: На этой иллюстрации изображён один из героев романов Александра Дюма. Это ...",
                         ["yTmoecJt-Bo.jpg"],
                         ["Д’Артаньян"],)
            },
            {
                "type": "PartOfSpeech",
                "data": ("Вопрос 8:Мальчишка на этой иллюстрации запечатлён \nв одной из самых ярких сцен, раскрывающих его характер. Кого вы видите?",
                         ["cUG_qRHyl_M.jpg"],
                         ["Тома Сойера",])
            },
            {
                "type": "PartOfSpeech",
                "data": (
                    "Вопрос 9: \nНа этой иллюстрации вы видите довольно пугающую сцену. Как вы думаете, чем она закончится? Если вы легко это вспомните, то значит вы узнали ...",
                    ["7erj7psCtUg.jpg"],
                    ["Гулливера"])
            },
            {
                "type": "PartOfSpeech",
                "data": (
                    "Вопрос 10: \nКто из героев произведений Фёдора Достоевского изображен на это иллюстрации?",
                    ["8jjcaR2XfMQ.jpg"],
                    ["Родион Раскольников"])
            },
            {
                "type": "PartOfSpeech",
                "data": (
                    "Вопрос 11: Кого изобразил французский художник Эжен Делакруа на этой картине?",
                    ["ECT0qD5o5fk.jpg"],
                    ["Ребекку и Айвенго"])
            },

        ]
        self.create_question()

    def create_question(self):
        if self.current_question_index < len(self.questions):
            question_data = self.questions[self.current_question_index]["data"]
            question_type = self.questions[self.current_question_index]["type"]

            if question_type == "OneChoice":
                self.question = OneChoice(self.root, *question_data, self.next_question)

            elif question_type == "MultipleChoice":
                self.question = MultipleChoice(self.root, *question_data, self.next_question)

            elif question_type == "CheckDataEdit":
                self.question = CheckDataEdit(self.root, *question_data, self.next_question)

            elif question_type == "PartOfSpeech":
                self.question = PartOfSpeechQuestion(self.root, *question_data, self.next_question)

            elif question_type == "DragAndDrop":
                self.question = DragAndDrop(self.root, *question_data, self.next_question)

    def next_question(self):
        self.dict[self.current_question_index] = self.question.get_result()
        print(self.dict)
        self.current_question_index += 1
        self.question.destroy()
        self.create_question()

        if self.current_question_index == len(self.questions):
            self.show_results()

    def show_results(self):
        incorrect_answers = [i + 1 for i, result in enumerate(self.dict.values()) if not result]
        if not incorrect_answers:
            messagebox.showinfo("Результат", "Вы ответили правильно на все вопросы!")
        else:
            message = f"Вы допустили ошибки в следующих вопросах:\n{', '.join(map(str, incorrect_answers))}"
            messagebox.showinfo("Результат", message)
        self.create_restart_button()

    def restart_test(self):
        self.current_question_index = 0
        self.dict = {}
        self.create_question()
        self.restart_button.destroy()

    def create_restart_button(self):
        self.restart_button = tk.Button(self.root, text="Пройти тест заново", command=self.restart_test)
        self.restart_button.pack()


if __name__ == "__main__":
    root = tk.Tk()
    app = QuestionManager(root)
    root.mainloop()
