import tkinter as tk
from tkinter import messagebox


class MultipleChoice:
    def __init__(self, root, question_label_text, question_text_list, correct_answers, callback):
        self.question_text_list = question_text_list
        self.question_label_text = question_label_text
        self.correct_answers = correct_answers
        self.callback = callback
        self.root = root

        self.label = tk.Label(root, text=question_label_text)
        self.label.pack()

        self.check_vars = []
        self.check_buttons = []

        for i, text in enumerate(question_text_list):
            var = tk.IntVar()
            self.check_vars.append(var)
            check_button = tk.Checkbutton(root, text=text, variable=var)
            check_button.pack()
            self.check_buttons.append(check_button)

        self.next_button = tk.Button(root, text="Далее", command=self.callback)
        self.next_button.pack(side=tk.BOTTOM)

    def destroy(self):
        self.label.destroy()
        for button in self.check_buttons:
            button.destroy()
        self.next_button.destroy()

    def get_result(self):
        selected_answers = [var.get() for var in self.check_vars]
        if selected_answers == self.correct_answers:
            return True
        else:
            return False
