import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk


class PartOfSpeechQuestion:
    def __init__(self, root, question_title, question_image_paths, correct_answers, callback):
        self.question_title = question_title
        self.question_image_paths = question_image_paths
        self.correct_answers = correct_answers
        self.callback = callback
        self.root = root
        self.title_label = tk.Label(root, text=question_title)
        self.title_label.pack()

        self.frame = tk.Frame(root)
        self.frame.pack()

        self.answer_entries = []

        for i, image_path in enumerate(question_image_paths):
            row = i // 2  # Calculate row index
            col = i % 2  # Calculate column index
            entry_frame = tk.Frame(self.frame)
            entry_frame.grid(row=row, column=col, padx=5, pady=5)  # Add padding between widgets
            image = Image.open(image_path)
            photo = ImageTk.PhotoImage(image)

            label = tk.Label(entry_frame, image=photo)
            label.image = photo  # Keep a reference to prevent garbage collection
            label.pack()

            entry = tk.Entry(entry_frame, width=20)  # You might need to adjust the width
            entry.pack()
            self.answer_entries.append(entry)

        self.next_button = tk.Button(root, text="Next", command=self.callback)
        self.next_button.pack(side=tk.BOTTOM)

    def destroy(self):
        self.title_label.destroy()
        self.frame.destroy()
        self.next_button.destroy()

    def get_result(self):
        entered_answers = [entry.get().lower() for entry in self.answer_entries]
        if entered_answers == self.correct_answers:
            return True
        else:
            return False

# Example usage:
# root = tk.Tk()

# Example image paths (replace with your image paths)
# question_image_paths = ["first.png", "second.png", "third.png", "fourth.png"]
#
# # Correct answers
# correct_answers = ["noun", "verb", "", ""]
#
# question_title = "Part of Speech Identification"
#
# def callback():
#     result = question.get_result()
#     if result:
#         messagebox.showinfo("Result", "Correct!")
#     else:
#         messagebox.showerror("Result", "Incorrect!")
#
#
# question = PartOfSpeechQuestion(root, question_title, question_image_paths, correct_answers, callback)
# root.mainloop()
