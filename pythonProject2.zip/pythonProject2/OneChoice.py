import tkinter as tk


class OneChoice:
    def __init__(self, root, question_label_text, question_text_list, correct_answer_index, callback):
        self.question_text_list = question_text_list
        self.question_label_text = question_label_text
        self.correct_answer_index = correct_answer_index
        self.callback = callback
        self.root = root

        self.label = tk.Label(root, text=question_label_text)
        self.label.pack()

        self.radio_var = tk.IntVar(value=-1)

        for i, text in enumerate(question_text_list):
            radio_button = tk.Radiobutton(root, text=text, variable=self.radio_var, value=i)
            radio_button.pack()

        self.next_button = tk.Button(root, text="Далее", command=self.callback)
        self.next_button.pack(side=tk.BOTTOM)

    def destroy(self):
        self.label.destroy()
        for widget in self.root.winfo_children():
            widget.destroy()

    def get_result(self):
        return self.radio_var.get() == self.correct_answer_index
