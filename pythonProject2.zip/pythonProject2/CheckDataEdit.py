import tkinter as tk
from tkinter import messagebox
from datetime import datetime

class CheckDataEdit:
    def __init__(self, root, question_label_text, correct_answers, callback):
        self.question_label_text = question_label_text
        self.correct_answers = correct_answers
        self.callback = callback
        self.root = root

        self.label = tk.Label(root, text=question_label_text)
        self.label.pack()

        self.entry = tk.Entry(root)
        self.entry.pack()

        self.next_button = tk.Button(root, text="Далее", command=self.callback)
        self.next_button.pack()

    def destroy(self):
        self.label.destroy()
        self.entry.destroy()
        self.next_button.destroy()

    def get_result(self):
        user_answer = self.entry.get()
        return user_answer == self.correct_answers[0]

