import tkinter as tk
import tkinter.messagebox as messagebox


class DragAndDrop:
    def __init__(self, master, label, image_path, text_block, correct_field, callback):
        self.master = master
        self.result = None
        self.label = label
        self.callback = callback
        self.correct_field = correct_field
        self.image = tk.PhotoImage(file=image_path)
        self.image_width = self.image.width()
        self.image_height = self.image.height()

        self.frame = tk.Frame(self.master)
        self.frame.pack()

        self.image_label = tk.Label(self.frame, image=self.image)
        self.image_label.pack()

        self.block_color = "#FFD700"
        self.block_text = text_block
        self.block_width = 100
        self.block_height = 30

        block_x = (self.image_width - self.block_width) // 2
        block_y = self.image_height - self.block_height

        self.block_label = tk.Label(self.frame, text=self.block_text, bg=self.block_color, bd=0)
        self.block_label.place(x=block_x, y=block_y, width=self.block_width, height=self.block_height)

        self.drag_data = None
        self.x_offset = 0
        self.y_offset = 0

        self.block_label.bind("<ButtonPress-1>", self.on_block_button_press)
        self.block_label.bind("<B1-Motion>", self.on_block_button_motion)
        self.block_label.bind("<ButtonRelease-1>", self.on_block_button_release)

        self.label = tk.Label(master, text=self.label)
        self.label.pack()

        self.next_button = tk.Button(master, text="Далее", command=self.callback)
        self.next_button.pack()

    def on_block_button_press(self, event):
        self.x_offset = event.x
        self.y_offset = event.y

    def on_block_button_motion(self, event):
        x = self.block_label.winfo_x() + (event.x - self.x_offset)
        y = self.block_label.winfo_y() + (event.y - self.y_offset)

        # Restrict block label within image boundaries
        x = min(max(x, 0), self.image_width - self.block_width)
        y = min(max(y, 0), self.image_height - self.block_height)

        self.block_label.place(x=x, y=y)

    def check_filed(self, num):
        if self.correct_field == num:
            self.result = True
        else:
            self.result = False
        messagebox.showinfo("Enter", f"Вы переместили текст в {num} поле")

    def on_block_button_release(self, event):
        x = self.block_label.winfo_x()
        y = self.block_label.winfo_y()

        if x > 110 and x < 285 and (y > 60 and y < 100):
            self.check_filed(1)
        elif x > 110 and x < 285 and (y > 158 and y < 195):
            self.check_filed(2)
        elif x > 110 and x < 285 and (y > 285 and y < 325):
            self.check_filed(3)
        elif x > 110 and x < 285 and (y > 410 and y < 450):
            self.check_filed(4)
        else:
            messagebox.showinfo("Error", "Некорректное поле")

    def destroy(self):
        self.frame.destroy()
        self.image_label.destroy()
        self.label.destroy()
        self.next_button.destroy()

    def get_result(self):
        return self.result
